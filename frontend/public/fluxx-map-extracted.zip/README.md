# FLUXX Map — Extracted

Extracted from the uploaded `fluxx-main` repository.

## Core files
- `FluxMap.jsx` — original Live Flux Map page
- `utils/mockMapData.js` — original mock GeoJSON heatmap generator

## Map technology
- React
- `react-map-gl/maplibre`
- `maplibre-gl`
- GeoJSON Source + MapLibre heatmap Layer

## Required project dependencies
- react
- react-map-gl
- maplibre-gl
- lucide-react
- clsx

The original component also imports these project-local components:
- `../components/Card`
- `../components/StatsCard`

and uses the project's Tailwind/theme classes.

## Important
The extracted map currently uses:
1. MapLibre GL
2. CARTO Dark/Light basemaps
3. Esri World Imagery for Satellite mode
4. `generateMockHeatmapData(...)` for generated mock heatmap points

The mock generator should be replaced with the FLUXX CSV -> IDW pipeline when integrating it into the new system.
