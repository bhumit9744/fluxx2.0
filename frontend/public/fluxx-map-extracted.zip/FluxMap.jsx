import React, { useState, useMemo, useEffect } from 'react';
import { Clock, Filter, Layers } from 'lucide-react';
import { Card } from '../components/Card';
import { StatsCard } from '../components/StatsCard';
import { clsx } from 'clsx';
import Map, { NavigationControl, GeolocateControl, Source, Layer } from 'react-map-gl/maplibre';
import 'maplibre-gl/dist/maplibre-gl.css';
import { generateMockHeatmapData } from '../utils/mockMapData';

const heatmapLayerStyle = {
  id: 'aqi-heatmap',
  type: 'heatmap',
  paint: {
    'heatmap-weight': [
      'interpolate',
      ['linear'],
      ['get', 'mag'],
      0, 0,
      3, 1
    ],
    'heatmap-intensity': [
      'interpolate',
      ['linear'],
      ['zoom'],
      10, 1,
      15, 3
    ],
    'heatmap-color': [
      'interpolate',
      ['linear'],
      ['heatmap-density'],
      0, 'rgba(34, 197, 94, 0)', 
      0.2, '#22c55e',            
      0.5, '#eab308',            
      0.8, '#ef4444',            
      1, '#ffffff'               
    ],
    'heatmap-radius': [
      'interpolate',
      ['linear'],
      ['zoom'],
      10, 15,
      15, 40
    ],
    'heatmap-opacity': [
      'interpolate',
      ['linear'],
      ['zoom'],
      10, 0.8,
      18, 0.4
    ]
  }
};

const MAP_STYLES = {
  dark: { name: 'Dark Theme', url: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json' },
  light: { name: 'Light Theme', url: 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json' },
  satellite: { 
    name: 'Satellite', 
    url: {
      version: 8,
      sources: {
        "esri-satellite": {
          type: "raster",
          tiles: ["https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"],
          tileSize: 256,
          attribution: "&copy; Esri, Maxar, Earthstar Geographics"
        }
      },
      layers: [
        {
          id: "satellite",
          type: "raster",
          source: "esri-satellite",
          minzoom: 0,
          maxzoom: 22
        }
      ]
    }
  }
};

export function FluxMap() {
  const [viewState, setViewState] = useState({
    longitude: 73.8567, 
    latitude: 18.5204,
    zoom: 12,
    pitch: 45,
    bearing: 0
  });

  const [activeStyle, setActiveStyle] = useState('dark');
  const [centerPoint, setCenterPoint] = useState({ longitude: 73.8567, latitude: 18.5204 });

  // Request live geolocation on mount
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { longitude, latitude } = position.coords;
          // Fly to the new location smoothly
          setViewState(prev => ({ ...prev, longitude, latitude, zoom: 13, transitionDuration: 2000 }));
          // Update the basis for heatmap data generation
          setCenterPoint({ longitude, latitude });
        },
        (error) => {
          console.warn("Geolocation permission denied or unavailable:", error);
        },
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
      );
    }
  }, []);

  // Generate heatmap data based on the Live location logic
  const data = useMemo(() => generateMockHeatmapData(centerPoint.longitude, centerPoint.latitude, 0.08, 600), [centerPoint.longitude, centerPoint.latitude]);

  return (
    <div className="flex flex-col h-full gap-6">
      <div className="grid grid-cols-4 gap-4">
        <StatsCard title="AQI" value="132" color="text-yellow-400" />
        <StatsCard title="PM2.5" value="85" color="text-red-400" />
        <StatsCard title="CO" value="0.9" color="text-green-400" />
        <StatsCard title="NO2" value="45" color="text-blue-400" />
      </div>
      
      <div className="flex items-center justify-between">
         <div>
            <h2 className="text-2xl font-bold mb-1 text-main transition-colors">Live Flux Map</h2>
            <p className="text-muted text-sm transition-colors">Real-time volumetric mapping powered by MapLibre GL.</p>
         </div>
         <div className="flex gap-3">
           <div className="relative">
             <select className="bg-surface border border-theme rounded-lg px-4 py-2 text-sm text-main appearance-none focus:outline-none focus:border-brand-primary cursor-pointer hover:bg-glass transition-colors">
               <option>Last 15 minutes</option>
               <option>Last 1 hour</option>
               <option>Last 24 hours</option>
             </select>
             <Clock className="w-4 h-4 text-muted absolute right-3 top-2.5 pointer-events-none transition-colors" />
           </div>
           <button className="p-2 bg-surface border border-theme rounded-lg hover:bg-glass text-muted hover:text-brand-primary transition-colors cursor-pointer">
             <Filter className="w-4 h-4" />
           </button>
         </div>
      </div>

      <div className="flex-1 min-h-[500px] relative rounded-2xl overflow-hidden glass-card border-theme p-1 flex transition-colors shadow-lg">
        
        <div className="w-full h-full rounded-xl overflow-hidden relative isolate pointer-events-auto bg-background">
          <Map
            {...viewState}
            onMove={evt => setViewState(evt.viewState)}
            mapStyle={MAP_STYLES[activeStyle].url}
            attributionControl={true}
          >
            <NavigationControl position="top-right" />
            <GeolocateControl position="top-right" positionOptions={{ enableHighAccuracy: true }} trackUserLocation={true} />
            
            {/* Map Style Toggle */}
            <div className="absolute top-4 left-4 z-10 flex gap-1 bg-surface/90 backdrop-blur-md p-1 rounded-xl border border-theme shadow-md">
              <div className="flex items-center px-2 mr-1">
                 <Layers className="w-4 h-4 text-muted" />
              </div>
              {Object.entries(MAP_STYLES).map(([key, style]) => (
                 <button 
                    key={key}
                    onClick={() => setActiveStyle(key)}
                    className={clsx(
                      "px-3 py-1.5 text-[11px] uppercase tracking-wider font-bold rounded-lg transition-all cursor-pointer",
                      activeStyle === key 
                        ? "bg-brand-primary text-white shadow-sm" 
                        : "text-muted hover:text-main hover:bg-glass"
                    )}
                 >
                    {style.name}
                 </button>
              ))}
            </div>

            <Source type="geojson" data={data}>
              <Layer {...heatmapLayerStyle} />
            </Source>
          </Map>
        </div>

        {/* Floating Legends */}
        <div className="absolute bottom-6 right-6 flex flex-col gap-3 pointer-events-none z-10">
          <Card className="!p-4 !rounded-xl border-theme bg-surface/90 backdrop-blur-md pointer-events-auto shadow-lg">
             <h4 className="text-xs font-semibold uppercase tracking-wider mb-3 text-muted transition-colors">AQI Legend</h4>
             <div className="flex flex-col gap-2">
                {[
                  { range: '0 - 50', label: 'Good', color: 'bg-brand-secondary' },
                  { range: '51 - 100', label: 'Moderate', color: 'bg-brand-warning' },
                  { range: '150+', label: 'Severe', color: 'bg-brand-alert' },
                ].map(l => (
                  <div key={l.label} className="flex items-center gap-3 text-sm">
                     <span className={clsx("w-3 h-3 rounded-full", l.color)}></span>
                     <span className="w-16 font-mono font-medium text-main transition-colors">{l.range}</span>
                     <span className="text-muted font-medium transition-colors">{l.label}</span>
                  </div>
                ))}
             </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
