// Helper to generate a realistic GeoJSON FeatureCollection
export function generateMockHeatmapData(centerLng, centerLat, radiusDegrees = 0.05, numPoints = 300) {
  const features = [];
  
  for (let i = 0; i < numPoints; i++) {
    // Generate organic clusters by using normal-like distribution approximation
    const u = Math.random() + Math.random() + Math.random() - 1.5;
    const v = Math.random() + Math.random() + Math.random() - 1.5;
    
    const lng = centerLng + u * radiusDegrees;
    const lat = centerLat + v * radiusDegrees;
    
    // Simulate AQI value based on proximity to center (simulated industrial zone)
    const distance = Math.sqrt(u * u + v * v);
    let baseAqi = 150 - (distance * 100); 
    
    // Add random noise
    baseAqi += (Math.random() - 0.5) * 50;
    
    const aqi = Math.max(0, Math.min(300, baseAqi));

    features.push({
      type: 'Feature',
      properties: {
        aqi: aqi,
        mag: aqi / 100 // weight mapped roughly for the heatmap engine
      },
      geometry: {
        type: 'Point',
        coordinates: [lng, lat]
      }
    });
  }

  return {
    type: 'FeatureCollection',
    features
  };
}
